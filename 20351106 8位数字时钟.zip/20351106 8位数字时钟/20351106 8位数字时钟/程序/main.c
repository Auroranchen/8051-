//����ͷ�ļ�
#include <reg52.h>
#include <intrins.h>
//������������
#define uchar unsigned char
#define uint unsigned int

//����ܶ����
uchar code SMG_CODE[] = {/*0,1,2,3,4,5,6,7,8,9,��,*/
0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x00,0x40};
uchar array[8] = {0,0,0,0,0,0,0,0,}; //��ʾ������

//ʱ��
uchar H = 9,M = 59,S = 45;

uchar SS[] = {0,0,0,0,0,0,0,0};

uchar NZ_H = 8,NZ_M = 0;
uchar NZ_H2 = 14,NZ_M2 = 0;
uchar NZ_H3 = 18,NZ_M3 = 0;

uchar DJS = 0;

uchar Set = 0;


//��������
sbit SB1 = P1^0;
sbit SB2 = P1^1;
sbit SB3 = P1^2;
sbit SB4 = P1^3;
sbit SB5 = P1^4;

sbit LE1 = P2^0;
sbit LE2 = P2^1;

sbit BUZ = P3^2;

void Write_Duan(uchar x)
{
	P0 = x;
	LE1 = 1;
	LE1 = 0;
}

void Write_Wei1(uchar x)
{
	P0 = x;
	LE2 = 1;
	LE2 = 0;
}

//��ʱ����
void delayms(uint x)
{
	uchar i;
	while(x--)for(i = 0; i < 120; i++);
}

//��ʾ����
void Display(void)
{
	if(Set == 0)
	{
		SS[0] = SS[1] = SS[2] = SS[3] = 0;
		SS[4] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		if(DJS == 0){
		array[0] = H/10%10;
		array[1] = H%10;
		array[2] = 11;
		array[3] = M/10;
		array[4] = M%10;
		array[5] = 11;
		array[6] = S/10;
		array[7] = S%10;}
		else
		{
			array[0] = 10;
			array[1] = 10;
			array[2] = 10;
			array[3] = 10;
			array[4] = 10;
			array[5] = 10;
			array[6] = DJS/10;
			array[7] = DJS%10;
		}
	}
	else if(Set == 1)
	{
		SS[0] = SS[1] = 1;
		SS[2] = SS[3] = 0;
		SS[4] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = H/10%10;
		array[1] = H%10;
		array[2] = 11;
		array[3] = M/10;
		array[4] = M%10;
		array[5] = 11;
		array[6] = S/10;
		array[7] = S%10;
	}
	else if(Set == 2)
	{
		SS[0] = SS[1] = 0;
		SS[3] = SS[4] = 1;
		SS[2] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = H/10%10;
		array[1] = H%10;
		array[2] = 11;
		array[3] = M/10;
		array[4] = M%10;
		array[5] = 11;
		array[6] = S/10;
		array[7] = S%10;
	}
	else if(Set == 3)
	{
		SS[0] = SS[1] = SS[2] = SS[3] = 0;
		SS[4] = SS[5] = 0;
		SS[6] = SS[7] = 1;
		array[0] = H/10%10;
		array[1] = H%10;
		array[2] = 11;
		array[3] = M/10;
		array[4] = M%10;
		array[5] = 11;
		array[6] = S/10;
		array[7] = S%10;
	}
	else if(Set == 4)
	{
		SS[0] = SS[1] = 1;
		SS[2] = SS[3] = 0;
		SS[4] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = NZ_H/10%10;
		array[1] = NZ_H%10;
		array[2] = 11;
		array[3] = NZ_M/10;
		array[4] = NZ_M%10;
		array[5] = 10;
		array[6] = 10;
		array[7] = 10;
	}
	else if(Set == 5)
	{
		SS[0] = SS[1] = 0;
		SS[3] = SS[4] = 1;
		SS[2] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = NZ_H/10%10;
		array[1] = NZ_H%10;
		array[2] = 11;
		array[3] = NZ_M/10;
		array[4] = NZ_M%10;
		array[5] = 10;
		array[6] = 10;
		array[7] = 10;
	}
	else if(Set == 6)
	{
		SS[0] = SS[1] = 1;
		SS[2] = SS[3] = 0;
		SS[4] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = NZ_H2/10%10;
		array[1] = NZ_H2%10;
		array[2] = 11;
		array[3] = NZ_M2/10;
		array[4] = NZ_M2%10;
		array[5] = 10;
		array[6] = 10;
		array[7] = 10;
	}
	else if(Set == 7)
	{
		SS[0] = SS[1] = 0;
		SS[3] = SS[4] = 1;
		SS[2] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = NZ_H2/10%10;
		array[1] = NZ_H2%10;
		array[2] = 11;
		array[3] = NZ_M2/10;
		array[4] = NZ_M2%10;
		array[5] = 10;
		array[6] = 10;
		array[7] = 10;
	}
	else if(Set == 8)
	{
		SS[0] = SS[1] = 1;
		SS[2] = SS[3] = 0;
		SS[4] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = NZ_H3/10%10;
		array[1] = NZ_H3%10;
		array[2] = 11;
		array[3] = NZ_M3/10;
		array[4] = NZ_M3%10;
		array[5] = 10;
		array[6] = 10;
		array[7] = 10;
	}
	else if(Set == 9)
	{
		SS[0] = SS[1] = 0;
		SS[3] = SS[4] = 1;
		SS[2] = SS[5] = 0;
		SS[6] = SS[7] = 0;
		array[0] = NZ_H3/10%10;
		array[1] = NZ_H3%10;
		array[2] = 11;
		array[3] = NZ_M3/10;
		array[4] = NZ_M3%10;
		array[5] = 10;
		array[6] = 10;
		array[7] = 10;
	}
}

//����ɨ�躯��
void Scankey(void)
{
	if(SB1 == 0) //����
	{
		delayms(10);
		if(SB1 == 0)
		{
			if(++Set == 10)Set = 0;
			while(SB1 == 0);
		}
	}
	if(SB2 == 0) //��
	{
		delayms(10);
		if(SB2 == 0)
		{
			switch(Set)
			{
				case 1: if(H < 23)H++; break;
				case 2: if(M < 59)M++; break;
				case 3: if(S < 59)S++; break;
				case 4: if(NZ_H < 23)NZ_H++; break;
				case 5: if(NZ_M < 59)NZ_M++; break;
				case 6: if(NZ_H2 < 23)NZ_H2++; break;
				case 7: if(NZ_M2 < 59)NZ_M2++; break;
				case 8: if(NZ_H3 < 23)NZ_H3++; break;
				case 9: if(NZ_M3 < 59)NZ_M3++; break;
			}
			while(SB2 == 0);
		}
	}
	if(SB3 == 0) //��
	{
		delayms(10);
		if(SB3 == 0)
		{
			switch(Set)
			{
				case 1: if(H > 0)H--; break;
				case 2: if(M > 0)M--; break;
				case 3: if(S > 0)S--; break;
				case 4: if(NZ_H > 0)NZ_H--; break;
				case 5: if(NZ_M > 0)NZ_M--; break;
				case 6: if(NZ_H2 > 0)NZ_H2--; break;
				case 7: if(NZ_M2 > 0)NZ_M2--; break;
				case 8: if(NZ_H3 > 0)NZ_H3--; break;
				case 9: if(NZ_M3 > 0)NZ_M3--; break;
			}
			while(SB3 == 0);
		}
	}
	if(SB4 == 0) //����
	{
		delayms(10);
		if(SB4 == 0)
		{
			Set = 0;
			while(SB4 == 0);
		}
	}
	if(SB5 == 0)
	{
		delayms(10);
		if(SB5 == 0)
		{
			while(SB5 == 0);
			DJS = 60;
		}
	}
}

//������
void main(void)
{
	//��ʼ��
	TMOD = 0x01;
	TH0 = (65536 - 4000)>>8;
  TL0 = (65536 - 4000)&0xff;
	TR0 = 1;
	ET0 = 1;
	EA = 1;
  while(1)
  {
		Display(); //��ʾ
		Scankey(); //ɨ�谴��
		if(((H == NZ_H&&M == NZ_M)||(H == NZ_H2&&M == NZ_M2)||((H == NZ_H3&&M == NZ_M3)))&&S < 5)BUZ = ~BUZ;
		else if(M == 59&&S >= 50)
		{
			if(S%2 == 0)BUZ = 0;
			else BUZ = 1;
		}
		else
		{
			BUZ = 1;
		}
		delayms(100); //��ʱ
  }
}

//��ʱ��ɨ������ܺͼ�ʱ
void ET0_T0(void) interrupt 1
{
  static uint i = 0,wei = 0xfe;
	static uint t = 0;
  TH0 = (65536 - 4000)>>8;
  TL0 = (65536 - 4000)&0xff;
	Write_Duan(0x00);
	Write_Wei1(wei);
	if(SS[i] == 0)
	{
		Write_Duan(SMG_CODE[array[i]]);
	}
	else
	{
		if(t < 125)
		{
			Write_Duan(SMG_CODE[array[i]]);
		}
		else
		{
			Write_Duan(0x00);
		}
	}
  wei = wei<<1|0x01;
  if(++i == 8){i = 0; wei = 0xFE;}
	if(++t >= 250)
	{
		t = 0;
		if(DJS > 0)DJS--;
		S++;
		if(S >= 60){S = 0; M++;}
		if(M >= 60){M = 0; H++;}
		if(H >= 24)
		{
			H = 0;
		}
	}
}
